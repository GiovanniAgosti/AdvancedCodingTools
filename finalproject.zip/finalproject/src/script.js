console.clear();

//SYNTH SLIDERS
let source1,source2,source3,lfoRate,lfoAmnt1,lfoAmnt2,cutoff,reso,envAmnt,att1,dcy1,stn1,rls1,att2,dcy2,stn2,rls2;

var t1 = document.getElementById("t1");
var t2 = document.getElementById("t2");
var o1 = document.getElementById("o1");
var o2 = document.getElementById("o2");


var source1Slider = document.getElementById("20");
var source2Slider = document.getElementById("21");
var source3Slider = document.getElementById("22");

var lfoRateSlider = document.getElementById("23");
var lfoAmnt1Slider = document.getElementById("24");
var lfoAmnt2Slider = document.getElementById("25");

var cutoffSlider = document.getElementById("26");
var resoSlider = document.getElementById("27");
var envAmntSlider = document.getElementById("28");

var att1Slider = document.getElementById("29");
var dcy1Slider = document.getElementById("30");
var stn1Slider = document.getElementById("31");
var rls1Slider = document.getElementById("32");

var att2Slider = document.getElementById("33");
var dcy2Slider = document.getElementById("34");
var stn2Slider = document.getElementById("35");
var rls2Slider = document.getElementById("36");

var pointer = 0;
var octave1 = -1;
var octave2 = 0;

o1.oninput = function() {
  octave1 = this.value;
}
o2.oninput = function() {
  octave2 = this.value;
}

//EQUAL TEMPERAMENT SYSTEM
const semitone = Math.pow(2, 1/12);
var c = 440 * Math.pow(semitone,3);
var notes = [];
for (i=0; i<12; i++){
  notes[i] = c * Math.pow(semitone, i);
}


//KEYBOARD RELATED CODE

const WHITE_KEYS = ['a', 's', 'd', 'f', 'g', 'h', 'j']
const BLACK_KEYS = ['w', 'e', 't', 'y', 'u']

const keys = document.querySelectorAll('.key')
const whiteKeys = document.querySelectorAll('.key.white')
const blackKeys = document.querySelectorAll('.key.black')


document.addEventListener('keydown', e => {
  if (e.repeat) return
  const key = e.key
  const whiteKeyIndex = WHITE_KEYS.indexOf(key)
  const blackKeyIndex = BLACK_KEYS.indexOf(key)

  if (whiteKeyIndex > -1) startNote(whiteKeys[whiteKeyIndex])
  if (blackKeyIndex > -1) startNote(blackKeys[blackKeyIndex])
})

document.addEventListener('keyup', e => {
  if (e.repeat) return
  const key = e.key
  const whiteKeyIndex = WHITE_KEYS.indexOf(key)
  const blackKeyIndex = BLACK_KEYS.indexOf(key)

  if (whiteKeyIndex > -1) stopNote(whiteKeys[whiteKeyIndex])
  if (blackKeyIndex > -1) stopNote(blackKeys[blackKeyIndex])
})

keys.forEach(key => {
  key.addEventListener('mousedown', () => startNote(key))
  key.addEventListener('mouseup', () => stopNote(key))
})

//CREATING THE LFOs
const lfoCutoff = new Tone.LFO;
lfoCutoff.frequency.value = 0;
lfoCutoff.min = 0;
lfoCutoff.max = 0;

const vibrato = new Tone.Vibrato();
vibrato.frequency.value = 0;
vibrato.depth.value = 0;

lfoAmnt1Slider.oninput = function() {
  vibrato.depth.value = this.value/100;
}




// CREATING TWO OSCILLATORS AND NOISE SOURCE
const osc1 = new Tone.Oscillator();
osc1.type = "triangle";
t1.oninput = function() {
  osc1.type = this.value;
}
osc1.volume.value = -10;
source1Slider.oninput = function() {
  osc1.volume.value = this.value -126;
}

const osc2 = new Tone.Oscillator();
osc2.type = "triangle";
t2.oninput = function() {
  osc2.type = this.value;
}
osc2.volume.value = -10;
source2Slider.oninput = function() {
  osc2.volume.value = this.value -126;
}

const noise = new Tone.Noise();
noise.volume.value = -100;
source3Slider.oninput = function() {
  noise.volume.value = this.value -126;
}



// CREATING AMPLITUDE ENVELOPE AND IT'S NODE
const ampEnv = new Tone.Envelope({})
const ampEnvNode = new Tone.Gain();

ampEnv.attack = 0.001;
ampEnv.decay = 0.5;
ampEnv.sustain = 0;
ampEnv.release = 0.2;

att2Slider.oninput = function() {
  ampEnv.attack = this.value/1000;
}
dcy2Slider.oninput = function() {
  ampEnv.decay = this.value/1000;
}
stn2Slider.oninput = function() {
  ampEnv.sustain = this.value/1000;
}
rls2Slider.oninput = function() {
  ampEnv.release = this.value/1000;
}




//CREATING LOWPASS FILTER AND ITS CONTROL SIGNAL
const fltEnv = new Tone.Envelope();
const mainSignal = new Tone.Signal();
const freqNode = new Tone.Gain();


fltEnv.attack = 0.001;
fltEnv.decay = 0;
fltEnv.sustain = 1;
fltEnv.release = 0.001;


att1Slider.oninput = function() {
  fltEnv.attack = this.value/1000;
}
dcy1Slider.oninput = function() {
  fltEnv.decay = this.value/1000;
}
stn1Slider.oninput = function() {
  fltEnv.sustain = this.value/1000;
}
rls1Slider.oninput = function() {
  fltEnv.release = this.value/1000;
}

const filter1 = new Tone.Filter();
const filter2 = new Tone.AutoFilter();
filter1.type = "lowpass";
/*filter1.frequency.value = 12000;*/
filter1.Q.value = 0.7;

mainSignal.value = 20000
filter2.baseFrequency = 20000
filter2.frequency = 0
filter2.octaves = 0

lfoRateSlider.oninput = function() {
  filter2.frequency = this.value;
  vibrato.frequency.value = this.value/10;
}

lfoAmnt2Slider.oninput = function() {
  filter2.octaves = this.value/20;
}

cutoffSlider.oninput = function() {
  mainSignal.value = this.value;
  filter2.baseFrequency = this.value;
}

envAmntSlider.oninput = function() {
}

mainSignal.connect(freqNode);
lfoCutoff.connect(freqNode);

fltEnv.connect(freqNode.gain);
freqNode.connect(filter1.frequency);

resoSlider.oninput = function() {
  filter1.Q.value = this.value;
}




// TRIGGERING NOTE ON AND OFF

function startNote(key) {
  key.classList.add('active')
  osc1.frequency.value = notes[parseInt(key.id)] * Math.pow(2,octave1);
  osc2.frequency.value = notes[parseInt(key.id)] * Math.pow(2,octave2);
  osc1.start();
  osc2.start();
  noise.start();
  filter2.start();
  ampEnv.triggerAttack();
  fltEnv.triggerAttack();
  console.log(lfoCutoff.min)
  console.log(lfoCutoff.max)

  
}
function stopNote(key) {
  key.classList.remove('active')
  ampEnv.triggerRelease();
  fltEnv.triggerRelease();
  osc1.stop("+rlsAmp");
  osc2.stop("+rlsAmp");
  noise.stop("+rlsAmp");
  filter2.stop("+rlsAmp");
}


//ROUTING
osc1.connect(filter1);
osc2.connect(filter1);
noise.connect(filter1);
filter1.connect(filter2);
filter2.connect(ampEnvNode);
ampEnv.connect(ampEnvNode.gain);
ampEnvNode.connect(vibrato);
vibrato.connect(Tone.Master);